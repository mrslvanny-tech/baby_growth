## Iteration - UI Revamp: Settings & Big Tree Visual (v1.8)
- UI Changes:
  - Removed Profile header from Home, moved to a new Settings page to keep Home pure and clean.
  - Added centered interactive Time Tag (Days/Months/Countdown toggle) on Home.
  - Redesigned GrowthTree: Now a flourishing glassmorphic full tree. Nodes light up as "buds" across the branches.
  - Changed "Heartbeat" concept to "Watering/Nutrients" for the tree.
- Logic Changes:
  - Time tag cycles between Days, Months, and Countdown.
- Routing Changes:
  - Added `/settings` route.

## Iteration - UI Polish & Personalization Loop (v1.7)
- UI Changes:
  - Growth Tree shape and animation redesigned to feature a fluid, SwiftUI-style breathing blob effect.
  - Buttons globally changed from a pale green to an iOS system vibrant green (#34C759).
  - Added a "Profile Edit" bottom sheet accessible from the Home page top header.
- Logic Changes:
  - Fixed an infinite loop bug in the Home screen that caused the Share Card to pop up repeatedly after saving a record.
  - Profile data (name, avatar, birth date) is now stored and fetched from localStorage.