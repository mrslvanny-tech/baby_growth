# PRD: 小芽成长 (Sprout Growth) V1.8
## Core Flow
1. **Onboarding**: Create baby profile (name, birth date, avatar). Clean iOS settings-like form.
2. **Home**: 
   - Top: Settings icon (top right). Centered interactive time tag (Days since birth / Month age / Countdown to next milestone toggle).
   - Middle (35-45%): A flourishing full tree with iOS glassmorphism. Recorded moments light up buds/leaves on the tree.
   - Bottom: "Record New Growth" sticky button, and "Watering/Nutrient" (previously Heartbeat) button.
   - Watering: Triggers a fluid, breathing pulse on the entire tree, symbolizing nutrient absorption.
3. **Settings**:
   - Independent page (`/settings`).
   - Edit profile (Avatar, Name, Birthday).
   - Links: Help Center, Legal Notices.
4. **Template Selection**: 
   - Top segmented control to toggle between `Island Map` and `Card List` (Default).
   - **Card List**: Sectioned list.
   - **Island Map**: Game-style winding path layout.
5. **Record Edit**: 
   - Refined SwiftUI-style form. Save triggers bud lighting animation on the tree.
6. **Share Card**: High-quality card. Supports custom records.

## Design System
- iOS Native / SwiftUI feel
- System fonts, SF Symbols (use Lucide with light stroke)
- Large rounded corners (16pt / 1rem `rounded-2xl` for typical cards), generous whitespace
- Low saturation colors (milky white, light green, light blue), primary #34C759.
- Glassmorphism for the Growth Tree.