import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Onboarding from './pages/Onboarding';
import Home from './pages/Home';
import Templates from './pages/Templates';
import RecordPage from './pages/Record';
import Share from './pages/Share';
import Measurements from './pages/Measurements';
import Settings from './pages/Settings';

const App = () => {
  return (
    <>
      <style>{`
        * {
          font-family: ui-rounded, "SF Pro Rounded", "PingFang SC", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        }
      `}</style>
      <BrowserRouter>
        <Routes>
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/home" element={<Home />} />
        <Route path="/templates" element={<Templates />} />
        <Route path="/record" element={<RecordPage />} />
        <Route path="/share" element={<Share />} />
        <Route path="/measurements" element={<Measurements />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/onboarding" replace />} />
      </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;