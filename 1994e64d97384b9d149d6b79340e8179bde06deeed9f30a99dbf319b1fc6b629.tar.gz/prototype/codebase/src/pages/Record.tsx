import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { ChevronLeft, ImagePlus, Activity, Smile, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GROWTH_NODES } from '../components/GrowthMap';

const TEMPLATES: Record<string, { title: string, desc: string }> = {
  turn_over: { title: "第一次翻身", desc: "你第一次自己翻过身。原来探索世界，是从一次小小的转身开始。" },
  walk: { title: "第一次走路", desc: "你第一次自己向前走了三步，从这一天起，世界又大了一点。" },
  call_papa: { title: "第一次叫爸爸/妈妈", desc: "这一天，小树长出了一颗最甜的果实。" },
  custom: { title: "", desc: "" }
};

const MOODS = [
  { id: 'happy', icon: '😄', color: 'bg-amber-100 text-amber-600 border-amber-400' },
  { id: 'proud', icon: '😎', color: 'bg-blue-100 text-blue-600 border-blue-400' },
  { id: 'loved', icon: '🥰', color: 'bg-rose-100 text-rose-600 border-rose-400' },
  { id: 'excited', icon: '🤩', color: 'bg-violet-100 text-violet-600 border-violet-400' },
];

const POSITIVE_EMOJIS = [
  '😊', '👶', '🔄', '😆', '👀', '🪑', '🦷', '🥣', '🐛', '👏', '👋', '👩', '👨', '🧍', '👣', '👉', '🥄', '🏃', '🦘', '💬', '🤝', '🎁', '🎵', '🎨', '🚽', '👕', '🚲', '1️⃣', '📖', '🏊', '🎒',
  '🌟', '✨', '🎈', '🎉', '🍀', '🌻', '🍎', '🌈', '🚀', '👑', '🧸', '🐣', '🌸', '🏆', '💡', '📸', '🍼', '💪', '💖', '🥰'
];

export default function RecordPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const templateId = searchParams.get('template') || 'turn_over';
  const isCustom = templateId === 'custom';
  
  const mapNode = GROWTH_NODES.find(n => n.id === templateId);
  const template = TEMPLATES[templateId] || { 
    title: mapNode?.title || "新成长瞬间", 
    desc: `记录下宝宝${mapNode?.title || "这珍贵的瞬间"}的难忘时刻，每一刻都值得被珍藏。` 
  };

  const [title, setTitle] = useState(isCustom ? '' : template.title);
  const [desc, setDesc] = useState(template.desc);
  
  const [emoji, setEmoji] = useState('✨');
  const [showEmojiSheet, setShowEmojiSheet] = useState(false);

  useEffect(() => {
    if (isCustom) {
      setEmoji(POSITIVE_EMOJIS[Math.floor(Math.random() * POSITIVE_EMOJIS.length)]);
    } else {
      setEmoji(mapNode?.icon || '✨');
    }
  }, [isCustom, mapNode?.icon]);

  // Set date to today by default
  const today = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState(today);
  const [mood, setMood] = useState<string | null>(null);

  const handleSave = () => {
    navigate(`/home?action=save_success&template=${templateId}&emoji=${encodeURIComponent(emoji)}&custom_title=${encodeURIComponent(title)}&desc=${encodeURIComponent(desc)}`);
  };

  return (
    <div className="w-full h-screen bg-[#F2F2F7] flex flex-col relative font-sans">
      <div className="bg-[#F2F2F7] z-10">
        <StatusBar color="black" floating={false} />
        <div className="h-14 flex items-center px-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-[#34C759] active:scale-95 transition-transform">
            <ChevronLeft size={28} strokeWidth={2.5} />
          </button>
          <div className="flex-1 text-center font-bold text-[17px] mr-8 text-gray-900">
            {isCustom ? "自定义记录" : title}
          </div>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto px-4 pt-2 pb-32 space-y-4">
        
        {/* Top: Header Info & Description */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[20px] shadow-sm overflow-hidden"
        >
          <div className="flex items-center px-4 py-3.5 border-b border-gray-100">
            <button 
              onClick={() => setShowEmojiSheet(true)}
              className="text-[28px] w-[52px] h-[52px] bg-[#F5F7F6] rounded-full flex items-center justify-center shrink-0 mr-3 active:scale-95 transition-transform border border-gray-100/50 shadow-inner"
            >
              {emoji}
            </button>
            {isCustom ? (
              <input 
                type="text" 
                placeholder="给这个瞬间起个名字..." 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-[17px] font-bold text-gray-900 outline-none placeholder:text-gray-300"
              />
            ) : (
              <div className="w-full text-[17px] font-bold text-gray-900 flex items-center justify-between">
                <span>{title}</span>
              </div>
            )}
          </div>
          <textarea 
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            className="w-full h-32 bg-transparent outline-none text-gray-900 text-[17px] leading-relaxed resize-none placeholder:text-gray-400 p-4"
            placeholder="写下一句话描述这个瞬间..."
          />
        </motion.div>

        {/* Middle: Date */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white rounded-[20px] shadow-sm overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="text-[17px] font-medium text-gray-900">发生日期</span>
            <input 
              type="date" 
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="text-[17px] text-gray-500 bg-transparent outline-none text-right flex-1"
            />
          </div>
        </motion.div>

        {/* Bottom: Optional Add-ons (Photo, Weight, Mood) */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-[20px] shadow-sm overflow-hidden"
        >
          {/* Photo */}
          <button className="w-full flex items-center justify-between px-4 py-4 border-b border-gray-100 active:bg-gray-50 transition-colors">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-500">
                <ImagePlus size={18} />
              </div>
              <span className="text-[16px] text-gray-900 font-medium">添加照片或视频</span>
            </div>
            <ChevronRight size={20} className="text-gray-300" />
          </button>

          {/* Height / Weight */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-500">
                <Activity size={18} />
              </div>
              <span className="text-[16px] text-gray-900 font-medium">身高/体重</span>
            </div>
            <div className="flex items-center space-x-2">
              <input 
                type="number" 
                placeholder="cm"
                className="w-16 text-[16px] text-gray-900 bg-gray-50 rounded-lg px-2 py-1.5 outline-none text-center placeholder:text-gray-400"
              />
              <span className="text-gray-300 text-sm">/</span>
              <input 
                type="number" 
                placeholder="kg"
                className="w-16 text-[16px] text-gray-900 bg-gray-50 rounded-lg px-2 py-1.5 outline-none text-center placeholder:text-gray-400"
              />
            </div>
          </div>

          {/* Mood */}
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-purple-50 rounded-full flex items-center justify-center text-purple-500">
                <Smile size={18} />
              </div>
              <span className="text-[16px] text-gray-900 font-medium">心情</span>
            </div>
            <div className="flex space-x-2">
              {MOODS.map(m => (
                <button
                  key={m.id}
                  onClick={() => setMood(m.id)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-[18px] border-2 transition-all ${
                    mood === m.id ? m.color : 'bg-gray-50 border-transparent grayscale opacity-50'
                  }`}
                >
                  {m.icon}
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </main>

      <div className="absolute bottom-0 left-0 w-full bg-[#F2F2F7] px-4 pt-4 pb-6 z-40">
        <button 
          onClick={handleSave}
          disabled={!title}
          className="w-full bg-[#34C759] disabled:bg-gray-300 disabled:shadow-none text-white font-bold text-[17px] py-4 rounded-[20px] flex items-center justify-center active:scale-[0.98] transition-transform shadow-[0_8px_20px_rgba(52,199,89,0.3)]"
        >
          保存记录
        </button>
        <div className="h-[34px]"></div>
      </div>
      
      {/* Emoji Picker Sheet */}
      <AnimatePresence>
        {showEmojiSheet && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowEmojiSheet(false)}
              className="fixed inset-0 bg-black/40 z-[90] backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-[100] bg-[#F2F2F7] rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] flex flex-col h-[60vh]"
            >
              <div className="flex justify-center pt-3 pb-2 shrink-0" onClick={() => setShowEmojiSheet(false)}>
                <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
              </div>
              <div className="px-6 py-4 flex items-center justify-between shrink-0">
                <h3 className="text-[20px] font-bold text-gray-900">
                  选择一个专属图标
                </h3>
                <button onClick={() => setShowEmojiSheet(false)} className="text-[#34C759] font-bold text-[15px] bg-[#34C759]/10 px-3 py-1.5 rounded-full active:scale-95 transition-transform">完成</button>
              </div>
              
              <div className="flex-1 overflow-y-auto px-6 py-2 content-start flex flex-wrap gap-4 pb-12 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                {POSITIVE_EMOJIS.map(e => (
                  <button 
                    key={e}
                    onClick={() => { setEmoji(e); setShowEmojiSheet(false); }}
                    className={`text-[32px] w-[56px] h-[56px] rounded-[20px] flex items-center justify-center transition-all ${
                      emoji === e ? 'bg-[#34C759]/20 border-2 border-[#34C759]' : 'bg-white border-2 border-transparent shadow-sm active:scale-95'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
              <div className="pb-6 pt-2 bg-[#F2F2F7]">
                <HomeIndicator floating={false} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <HomeIndicator floating={true} />
    </div>
  );
}