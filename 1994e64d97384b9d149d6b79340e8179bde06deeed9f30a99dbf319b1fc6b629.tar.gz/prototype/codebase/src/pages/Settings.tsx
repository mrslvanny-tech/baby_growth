import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { ChevronLeft, RefreshCw, HelpCircle, FileText, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Settings() {
  const navigate = useNavigate();
  const defaultDate = new Date();
  defaultDate.setDate(defaultDate.getDate() - 128);
  
  const [profile, setProfile] = useState({ name: '小芽', date: defaultDate.toISOString().split('T')[0], avatar: 'https://picsum.photos/seed/baby1/200/200' });
  const [isEditing, setIsEditing] = useState(false);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('baby_profile');
    if (saved) setProfile(JSON.parse(saved));
  }, []);

  const handleSave = () => {
    localStorage.setItem('baby_profile', JSON.stringify(profile));
    setIsEditing(false);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };

  const cycleAvatar = () => {
    if (!isEditing) return;
    const seeds = ['baby1', 'baby2', 'cute', 'smile', 'joy', 'sun', 'star'];
    const nextSeed = seeds[Math.floor(Math.random() * seeds.length)] + Math.floor(Math.random() * 100);
    setProfile(p => ({ ...p, avatar: `https://picsum.photos/seed/${nextSeed}/200/200` }));
  };

  return (
    <div className="w-full h-screen bg-[#F2F2F7] flex flex-col font-sans">
      <div className="bg-white">
        <StatusBar color="black" floating={false} />
        <div className="h-14 flex items-center justify-between px-4 border-b border-gray-100">
          <button onClick={() => navigate(-1)} className="text-[#34C759] active:scale-95 transition-transform px-2 -ml-2 flex items-center">
            <ChevronLeft size={28} strokeWidth={2.5} />
            <span className="text-[17px]">返回</span>
          </button>
          <h1 className="text-[17px] font-bold text-gray-900">设置</h1>
          {isEditing ? (
            <button onClick={handleSave} className="text-[#34C759] font-bold text-[17px] px-2 -mr-2">保存</button>
          ) : (
            <button onClick={() => setIsEditing(true)} className="text-[#34C759] text-[17px] px-2 -mr-2">编辑</button>
          )}
        </div>
      </div>

      <main className="flex-1 overflow-y-auto pt-6 pb-12">
        <div className="px-4 mb-2">
          <h2 className="text-[13px] font-semibold text-gray-500 uppercase tracking-wider pl-4 mb-2">个人信息</h2>
          <div className="bg-white rounded-[20px] overflow-hidden shadow-sm">
            <div className="flex items-center justify-between px-4 py-4 border-b border-gray-100">
              <span className="text-[16px] text-gray-900">头像</span>
              <div className="relative group">
                <img src={profile.avatar} className="w-14 h-14 rounded-full object-cover bg-gray-50 shadow-sm border border-gray-100" />
                {isEditing && (
                  <button onClick={cycleAvatar} className="absolute bottom-0 right-0 bg-gray-900 text-white w-6 h-6 rounded-full flex items-center justify-center border-2 border-white">
                    <RefreshCw size={10} strokeWidth={3} />
                  </button>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between px-4 py-4 border-b border-gray-100">
              <span className="text-[16px] text-gray-900">昵称</span>
              {isEditing ? (
                <input 
                  type="text" 
                  value={profile.name}
                  onChange={e => setProfile({...profile, name: e.target.value})}
                  className="text-right text-[16px] text-gray-900 outline-none w-32 bg-gray-50 rounded-md px-2 py-1"
                />
              ) : (
                <span className="text-[16px] text-gray-500">{profile.name}</span>
              )}
            </div>

            <div className="flex items-center justify-between px-4 py-4">
              <span className="text-[16px] text-gray-900">出生日期</span>
              {isEditing ? (
                <input 
                  type="date" 
                  value={profile.date}
                  onChange={e => setProfile({...profile, date: e.target.value})}
                  className="text-right text-[16px] text-gray-900 outline-none w-40 bg-gray-50 rounded-md px-2 py-1"
                />
              ) : (
                <span className="text-[16px] text-gray-500">{profile.date}</span>
              )}
            </div>
          </div>
        </div>

        <div className="px-4 mt-8">
          <h2 className="text-[13px] font-semibold text-gray-500 uppercase tracking-wider pl-4 mb-2">支持与关于</h2>
          <div className="bg-white rounded-[20px] overflow-hidden shadow-sm">
            <button className="w-full flex items-center justify-between px-4 py-4 border-b border-gray-100 active:bg-gray-50 transition-colors">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#34C759]/10 rounded-full flex items-center justify-center text-[#34C759]">
                  <HelpCircle size={18} />
                </div>
                <span className="text-[16px] text-gray-900">帮助中心</span>
              </div>
              <ChevronRight size={20} className="text-gray-300" />
            </button>
            <button className="w-full flex items-center justify-between px-4 py-4 active:bg-gray-50 transition-colors">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-500">
                  <FileText size={18} />
                </div>
                <span className="text-[16px] text-gray-900">法律与隐私声明</span>
              </div>
              <ChevronRight size={20} className="text-gray-300" />
            </button>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-[13px] text-gray-400 font-medium">小芽成长 v1.8.0</p>
        </div>
      </main>

      <div className="bg-[#F2F2F7]">
        <HomeIndicator floating={false} />
      </div>

      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-gray-900/90 backdrop-blur-md text-white px-6 py-3 rounded-full shadow-lg z-50 text-[14px] font-bold"
          >
            设置已保存
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}