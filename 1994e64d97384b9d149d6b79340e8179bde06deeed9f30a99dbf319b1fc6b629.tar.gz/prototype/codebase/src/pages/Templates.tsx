import { useNavigate, useSearchParams } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { ChevronLeft, Search, Star, Footprints, MessageCircle, Plus, Map, LayoutList } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import GrowthMap from '../components/GrowthMap';

export default function Templates() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const viewMode = searchParams.get('view') || 'list'; // 'list' or 'map'

  const setViewMode = (mode: string) => {
    setSearchParams(prev => {
      const p = new URLSearchParams(prev);
      p.set('view', mode);
      return p;
    }, { replace: true });
  };

  const categories = [
    {
      title: "常用记录",
      icon: <Star className="text-yellow-400" size={20} fill="currentColor" />,
      items: [
        { id: 'turn_over', title: "第一次翻身", desc: "原来探索世界，是从一次小小的转身开始。" },
        { id: 'sit', title: "第一次独坐", desc: "脊背挺直，看见了不一样的风景。" }
      ]
    },
    {
      title: "大运动",
      icon: <Footprints className="text-[#34C759]" size={20} />,
      items: [
        { id: 'crawl', title: "第一次爬行", desc: "四肢并用，向着好奇的方向前进。" },
        { id: 'walk', title: "第一次走路", desc: "向前走了三步，世界又大了一点。" }
      ]
    },
    {
      title: "语言",
      icon: <MessageCircle className="text-[#A2C0D9]" size={20} />,
      items: [
        { id: 'call_papa', title: "第一次叫爸爸/妈妈", desc: "这一天，小树长出了一颗最甜的果实。" }
      ]
    }
  ];

  return (
    <div className="w-full h-screen bg-white flex flex-col font-sans">
      <div className="bg-white z-10">
        <StatusBar color="black" floating={false} />
        <div className="h-14 flex items-center px-4 border-b border-gray-50">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-gray-900">
            <ChevronLeft size={28} strokeWidth={2} />
          </button>
          <h1 className="flex-1 text-center text-lg font-bold mr-8">记录新成长</h1>
        </div>
        <div className="px-4 py-3 border-b border-gray-50 bg-white">
          <div className="flex bg-[#F5F7F6] rounded-full p-1 relative">
            <motion.div 
              className="absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-full shadow-[0_2px_8px_rgba(0,0,0,0.06)]"
              animate={{ left: viewMode === 'list' ? '4px' : 'calc(50%)' }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            />
            <button 
              onClick={() => setViewMode('list')}
              className={`flex-1 flex items-center justify-center space-x-1.5 py-2 text-[14px] font-bold relative z-10 transition-colors ${viewMode === 'list' ? 'text-gray-900' : 'text-gray-500'}`}
            >
              <LayoutList size={16} strokeWidth={2.5} />
              <span>卡片列表</span>
            </button>
            <button 
              onClick={() => setViewMode('map')}
              className={`flex-1 flex items-center justify-center space-x-1.5 py-2 text-[14px] font-bold relative z-10 transition-colors ${viewMode === 'map' ? 'text-gray-900' : 'text-gray-500'}`}
            >
              <Map size={16} strokeWidth={2.5} />
              <span>岛屿地图</span>
            </button>
          </div>
        </div>
      </div>

      <main className="flex-1 overflow-hidden bg-[#F7F9F8] relative flex flex-col">
        <AnimatePresence mode="wait">
          {viewMode === 'map' ? (
            <motion.div 
              key="map"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
              className="w-full h-full overflow-y-auto"
            >
              <GrowthMap />
            </motion.div>
          ) : (
            <motion.div 
              key="list"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="px-4 pt-6 pb-8 space-y-8 bg-white h-full overflow-y-auto"
            >
              <div className="bg-[#F5F7F6] rounded-full h-10 flex items-center px-4 mb-2">
                <Search size={18} className="text-gray-400" />
                <input 
                  type="text" 
                  placeholder="搜索成长瞬间..." 
                  className="bg-transparent flex-1 ml-2 text-sm outline-none text-gray-900 placeholder:text-gray-400"
                />
              </div>
              {categories.map((cat, i) => (
                <div key={cat.title}>
                  <div className="flex items-center space-x-2 mb-4">
                    {cat.icon}
                    <h2 className="font-bold text-gray-900">{cat.title}</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {cat.items.map(item => (
                      <button
                        key={item.id}
                        onClick={() => navigate(`/record?template=${item.id}`)}
                        className="bg-[#F7F9F8] p-4 rounded-[20px] text-left active:scale-95 transition-transform shadow-sm border border-transparent hover:border-gray-100"
                      >
                        <h3 className="font-bold text-gray-900 text-[15px] mb-1">{item.title}</h3>
                        <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">{item.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="pt-2">
                <button 
                  onClick={() => navigate('/record?template=custom')}
                  className="w-full border-2 border-dashed border-gray-200 rounded-[20px] py-4 text-sm font-semibold text-gray-400 flex items-center justify-center space-x-2 active:bg-gray-50 transition-colors"
                >
                  <Plus size={18} />
                  <span>自定义记录</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <div className="bg-white">
        <HomeIndicator floating={false} />
      </div>
    </div>
  );
}