import { useNavigate, useSearchParams } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { ChevronLeft, Download, Share as ShareIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { GROWTH_NODES } from '../components/GrowthMap';

const TEMPLATES: Record<string, { title: string, desc: string }> = {
  turn_over: { title: "第一次翻身", desc: "你第一次自己翻过身。原来探索世界，是从一次小小的转身开始。" },
  walk: { title: "第一次走路", desc: "你第一次自己向前走了三步，从这一天起，世界又大了一点。" },
  call_papa: { title: "第一次叫爸爸/妈妈", desc: "这一天，小树长出了一颗最甜的果实。" },
  custom: { title: "自定义成长", desc: "每一天都是全新的冒险，这个独特的瞬间已经被用心珍藏。" }
};

export default function Share() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const templateId = searchParams.get('template') || 'turn_over';
  const customTitle = searchParams.get('custom_title');
  const customEmoji = searchParams.get('emoji');
  const customDesc = searchParams.get('desc');
  
  const [profile, setProfile] = useState({ name: '小芽', date: '2023-10-01' });
  useEffect(() => {
    const saved = localStorage.getItem('baby_profile');
    if (saved) setProfile(JSON.parse(saved));
  }, []);

  const mapNode = GROWTH_NODES.find(n => n.id === templateId);
  const template = TEMPLATES[templateId] || { 
    title: mapNode?.title || "新成长瞬间", 
    desc: `记录下宝宝${mapNode?.title || "这珍贵的瞬间"}的难忘时刻，每一刻都值得被珍藏。` 
  };

  const displayTitle = customTitle || template.title;
  const displayEmoji = customEmoji || mapNode?.icon || '🌱';
  const displayDesc = customDesc || template.desc || "每一天都是全新的冒险，这个独特的瞬间已经被用心珍藏。";

  return (
    <div className="w-full h-screen bg-[#111111] flex flex-col text-white font-sans">
      <StatusBar color="white" floating={false} />
      
      <div className="h-14 flex items-center px-4 relative">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-white z-10">
          <ChevronLeft size={28} strokeWidth={2} />
        </button>
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="text-lg font-semibold">预览</h1>
        </div>
      </div>

      <main className="flex-1 flex flex-col items-center justify-center px-8 pb-10">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full bg-[#F5F7F6] rounded-[32px] overflow-hidden shadow-2xl shadow-white/5"
        >
          <div className="p-8 pb-10 text-center relative text-gray-900">
            <div className="w-16 h-16 mx-auto bg-white rounded-full flex items-center justify-center text-3xl shadow-sm mb-6 z-10 relative">
              🌱
            </div>
            
            <p className="text-[11px] text-gray-400 font-medium tracking-[0.2em] uppercase mb-2">Milestone</p>
            <h2 className="text-2xl font-bold mb-4">{template.title}</h2>
            
            <p className="text-[15px] text-gray-600 leading-relaxed mb-10 text-left px-2">
              "{template.desc}"
            </p>

            <div className="flex justify-between items-end border-t border-gray-200/60 pt-6">
              <div className="text-left">
                <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">{profile.name}来到世界</p>
                <p className="text-2xl font-bold font-serif text-[#34C759]">
                  {Math.ceil(Math.abs(new Date().getTime() - new Date(profile.date).getTime()) / (1000 * 60 * 60 * 24))} <span className="text-sm">天</span>
                </p>
              </div>
              <div className="text-right pb-1">
                <p className="text-[10px] text-gray-400 font-medium">来自「小芽成长」</p>
              </div>
            </div>
          </div>
        </motion.div>
      </main>

      <div className="bg-[#1C1C1E] rounded-t-[32px] px-6 pt-6 pb-4">
        <div className="flex justify-center space-x-6 mb-6">
          <button className="flex flex-col items-center space-y-2 group">
            <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center group-active:bg-white/20 transition-colors">
              <Download size={24} />
            </div>
            <span className="text-xs text-gray-400">保存相册</span>
          </button>
          <button className="flex flex-col items-center space-y-2 group">
            <div className="w-14 h-14 bg-[#07C160]/20 rounded-full flex items-center justify-center text-[#07C160] group-active:bg-[#07C160]/30 transition-colors">
              <ShareIcon size={24} />
            </div>
            <span className="text-xs text-gray-400">微信分享</span>
          </button>
        </div>
        <HomeIndicator floating={false} />
      </div>
    </div>
  );
}