import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Download, Share as ShareIcon, ChevronRight, Droplet, Settings, Clock, Sparkles, Sprout, ListTree } from 'lucide-react';
import GrowthTree from '../components/GrowthTree';
import { GROWTH_NODES } from '../components/GrowthMap';

const TEMPLATES: Record<string, { title: string, desc: string }> = {
  turn_over: { title: "第一次翻身", desc: "你第一次自己翻过身。原来探索世界，是从一次小小的转身开始。" },
  walk: { title: "第一次走路", desc: "你第一次自己向前走了三步，从这一天起，世界又大了一点。" },
  call_papa: { title: "第一次叫爸爸/妈妈", desc: "这一天，小树长出了一颗最甜的果实。" },
  custom: { title: "自定义成长", desc: "每一天都是全新的冒险，这个独特的瞬间已经被用心珍藏。" }
};

const DEFAULT_RECORDS = [
  { id: 'smile', title: '第一次微笑', date: '4个月前', icon: '😊' },
  { id: 'lift_head', title: '第一次抬头', date: '3个月前', icon: '👶' },
  { id: 'recognize', title: '第一次认人', date: '1个月前', icon: '👀' },
];

const WATER_TAGS = ['开心瞬间', '健康成长', '补充养料', '小确幸', '阳光明媚', '充满活力'];

const MOCK_WATERS = [
  { id: 'w1', text: '今天带你去了公园，晒了很久的太阳。', tag: '阳光明媚', date: '今天 09:30', icon: '☀️' },
  { id: 'w2', text: '胃口超好，吃光了所有的辅食！', tag: '健康成长', date: '昨天 12:15', icon: '🥣' }
];

export default function Home() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const action = searchParams.get('action');
  const templateId = searchParams.get('template') || 'turn_over';
  const showCard = searchParams.get('show_card') === 'true';
  const showWaterMenu = searchParams.get('sheet') === 'water_menu';
  const showWaterSheet = searchParams.get('sheet') === 'water';
  const showWaterList = searchParams.get('sheet') === 'water_list';

  const customTitle = searchParams.get('custom_title');
  const customEmoji = searchParams.get('emoji');
  const customDesc = searchParams.get('desc');

  const mapNode = GROWTH_NODES.find(n => n.id === templateId);
  const template = TEMPLATES[templateId] || { 
    title: mapNode?.title || "新成长瞬间", 
    desc: `记录下宝宝${mapNode?.title || "这珍贵的瞬间"}的难忘时刻，每一刻都值得被珍藏。` 
  };
  
  const displayTitle = customTitle || template.title;
  const displayEmoji = customEmoji || mapNode?.icon || '🌱';
  const displayDesc = customDesc || template.desc || "每一天都是全新的冒险，这个独特的瞬间已经被用心珍藏。";

  const [records, setRecords] = useState(DEFAULT_RECORDS);
  const [waterRecords, setWaterRecords] = useState(MOCK_WATERS);
  
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [waterCount, setWaterCount] = useState(0);
  const [waterText, setWaterText] = useState('');

  const [timeMode, setTimeMode] = useState(0); // 0: days, 1: months, 2: countdown

  // Profile Logic
  const defaultDate = new Date();
  defaultDate.setDate(defaultDate.getDate() - 128);
  const [profile, setProfile] = useState({ name: '小芽', date: defaultDate.toISOString().split('T')[0], avatar: 'https://picsum.photos/seed/baby1/200/200' });

  useEffect(() => {
    const saved = localStorage.getItem('baby_profile');
    if (saved) {
      setProfile(JSON.parse(saved));
    }
  }, []);

  const days = Math.ceil(Math.abs(new Date().getTime() - new Date(profile.date).getTime()) / (1000 * 60 * 60 * 24));
  const months = Math.floor(days / 30.44);
  const countdown = 365 - (days % 365);

  const toggleTimeMode = () => setTimeMode(m => (m + 1) % 3);

  useEffect(() => {
    if (action === 'save_success') {
      const newRecord = {
        id: templateId + Date.now(),
        title: displayTitle,
        date: '刚刚',
        icon: displayEmoji
      };
      
      setRecords(prev => {
        if (prev.find(item => item.title === displayTitle && item.date === '刚刚')) return prev;
        return [newRecord, ...prev];
      });
      setShowToast(true);
      setToastMsg(`已点亮芽点：${displayTitle}`);
      
      const timer = setTimeout(() => {
        setSearchParams(prev => {
          const newParams = new URLSearchParams(prev);
          newParams.set('show_card', 'true');
          newParams.delete('action');
          return newParams;
        }, { replace: true });
      }, 2500);
      
      return () => clearTimeout(timer);
    } else if (action === 'water_saved') {
      setWaterCount(prev => prev + 1);
      setShowToast(true);
      setToastMsg('大树吸收了养分');
      
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 3500);
      return () => clearTimeout(timer);
    } else {
      setShowToast(false);
    }
  }, [action, templateId, displayTitle, displayEmoji, setSearchParams]);

  const closeCard = () => {
    setSearchParams(prev => {
      const p = new URLSearchParams(prev);
      p.delete('show_card');
      return p;
    }, { replace: true });
  };

  const closeSheet = () => {
    setSearchParams(prev => {
      const p = new URLSearchParams(prev);
      p.delete('sheet');
      return p;
    }, { replace: true });
  };

  const saveWater = (text: string) => {
    const newRecord = {
      id: 'w' + Date.now(),
      text,
      tag: '补充养料',
      date: '刚刚',
      icon: '💧'
    };
    setWaterRecords(prev => [newRecord, ...prev]);
    setWaterText('');
    setSearchParams(prev => {
      const p = new URLSearchParams(prev);
      p.delete('sheet');
      p.set('action', 'water_saved');
      return p;
    }, { replace: true });
  };

  return (
    <div className="w-full h-screen bg-[#F7F9F8] flex flex-col relative overflow-hidden font-sans">
      <StatusBar color="black" floating={true} />
      
      {/* Top floating UI */}
      <div className="absolute top-[54px] w-full px-6 flex justify-between items-start z-20 pointer-events-none">
        <div className="flex-1"></div>
        <button 
          onClick={() => navigate('/settings')} 
          className="pointer-events-auto w-10 h-10 bg-white/70 backdrop-blur-xl rounded-full flex items-center justify-center shadow-[0_4px_15px_rgba(0,0,0,0.05)] border border-white/50 active:scale-95 transition-transform"
        >
          <Settings size={20} className="text-gray-700" />
        </button>
      </div>
      
      <main className="flex-1 pt-[72px] pb-[160px] overflow-y-auto block [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
        
        {/* Time Tag */}
        <div className="w-full pb-2 flex flex-col items-center justify-center relative z-10">
          <button 
            onClick={toggleTimeMode} 
            className="bg-white/70 backdrop-blur-xl px-5 py-2.5 rounded-full shadow-[0_4px_20px_rgba(0,0,0,0.04)] border border-white flex items-center space-x-2 active:scale-95 transition-transform"
          >
            <Clock size={16} className="text-[#34C759]" strokeWidth={2.5} />
            <span className="text-[14px] font-bold text-gray-800 tracking-wide">
              {timeMode === 0 && `${profile.name} 已来到世界 ${days} 天`}
              {timeMode === 1 && `${profile.name} 已经 ${months} 个月大了`}
              {timeMode === 2 && `距离下个生日还有 ${countdown} 天`}
            </span>
          </button>
        </div>

        {/* Tree Section */}
        <div className="flex flex-col items-center justify-center relative min-h-[380px]">
          <GrowthTree recordCount={records.length} waterCount={waterCount} />
        </div>

        {/* Carousel Section */}
        <div className="w-full mt-4 relative z-10">
          <div className="px-6 flex items-center justify-between mb-4">
            <h3 className="text-[17px] font-bold text-gray-900 flex items-center">
              已点亮瞬间
              <span className="ml-2 bg-[#34C759] text-white text-[12px] px-2 py-0.5 rounded-full font-bold shadow-sm">
                {records.length}
              </span>
            </h3>
          </div>
          
          <div className="w-full overflow-x-auto snap-x snap-mandatory flex space-x-3.5 px-6 pb-6 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
            {records.map((item, index) => (
              <motion.button 
                key={item.id} 
                whileTap={{ scale: 0.95 }}
                onClick={() => setSearchParams(prev => { 
                  const p = new URLSearchParams(prev);
                  p.set('show_card', 'true');
                  p.set('template', item.id);
                  p.set('emoji', item.icon);
                  p.set('custom_title', item.title);
                  return p;
                })}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="snap-start shrink-0 w-[110px] bg-white rounded-[24px] p-4 shadow-[0_8px_20px_rgb(0,0,0,0.03)] border border-white flex flex-col items-center justify-center text-center focus:outline-none"
              >
                <div className="w-12 h-12 bg-[#F5F7F6] rounded-full flex items-center justify-center text-[24px] mb-3 shadow-inner">
                  {item.icon}
                </div>
                <h4 className="text-[14px] font-bold text-gray-900 mb-1 leading-tight">{item.title}</h4>
                <p className="text-[11px] text-gray-400 font-medium">{item.date}</p>
              </motion.button>
            ))}
            
            <div className="snap-start shrink-0 w-[110px] bg-[#F5F7F6] border-2 border-dashed border-gray-200 rounded-[24px] flex flex-col items-center justify-center text-center p-4">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center mb-2 shadow-sm">
                <Sparkles size={16} className="text-gray-300" />
              </div>
              <p className="text-[12px] text-gray-400 font-bold">期待更多</p>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Action Buttons */}
      <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-[#F7F9F8] via-[#F7F9F8] to-transparent pt-16 pb-8 px-6 z-40 pointer-events-none">
        <div className="pointer-events-auto flex items-center space-x-3">
          <motion.button 
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/templates')}
            className="flex-1 bg-gray-900 text-white font-bold py-[18px] rounded-[24px] flex items-center justify-center space-x-2 relative overflow-hidden group shadow-[0_12px_30px_rgba(0,0,0,0.15)]"
          >
            <div className="absolute inset-0 bg-white/20 translate-y-full group-active:translate-y-0 transition-transform duration-300 ease-out"></div>
            <Plus size={22} strokeWidth={3} className="relative z-10" />
            <span className="relative z-10 text-[17px]">记录新成长</span>
          </motion.button>
          
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setSearchParams(prev => { prev.set('sheet', 'water_menu'); return prev; })}
            className="w-[60px] h-[60px] bg-white rounded-[20px] flex items-center justify-center text-[#4DACF0] shadow-[0_12px_30px_rgba(0,0,0,0.1)] border border-gray-100 shrink-0 relative overflow-hidden group"
          >
             <div className="absolute inset-0 bg-blue-50 opacity-0 group-active:opacity-100 transition-opacity"></div>
             <Droplet size={26} strokeWidth={2.5} className="relative z-10" />
          </motion.button>
        </div>
        <div className="h-[34px]"></div>
      </div>
      
      <HomeIndicator floating={true} />

      {/* Toast Notification */}
      <AnimatePresence>
        {showToast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-[140px] left-6 right-6 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-[0_20px_40px_rgb(0,0,0,0.15)] z-50 flex items-center justify-between border border-white"
          >
            <div>
              <p className="font-bold text-gray-900 text-[15px]">{toastMsg}</p>
              {action === 'save_success' && (
                <p className="text-xs text-gray-500 mt-1.5 font-medium flex items-center"><span className="mr-1">✨</span> 大树上亮起了一个新芽</p>
              )}
              {action === 'water_saved' && (
                <p className="text-xs text-gray-500 mt-1.5 font-medium flex items-center"><span className="mr-1">🌿</span> 大树因为你的记录变得更生机勃勃了</p>
              )}
            </div>
            {action === 'save_success' && (
              <button 
                onClick={() => setSearchParams(prev => { const np = new URLSearchParams(prev); np.set('show_card', 'true'); np.delete('action'); return np; })}
                className="bg-[#34C759] text-white px-4 py-2.5 rounded-xl text-[14px] font-bold flex items-center space-x-1.5 active:scale-95 transition-transform shadow-sm"
              >
                <ShareIcon size={16} strokeWidth={2.5} />
                <span>纪念卡</span>
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Water Menu Bottom Sheet */}
      <AnimatePresence>
        {showWaterMenu && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeSheet}
              className="fixed inset-0 bg-black/40 z-[90] backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-[100] bg-[#F7F9F8] rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] flex flex-col px-6 pb-8"
            >
              <div className="flex justify-center pt-3 pb-6" onClick={closeSheet}>
                <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
              </div>
              <div className="space-y-3">
                <button 
                  onClick={() => setSearchParams(prev => { const p = new URLSearchParams(prev); p.set('sheet', 'water'); return p; })}
                  className="w-full bg-white rounded-2xl p-5 flex items-center justify-between shadow-sm active:scale-95 transition-transform border border-white"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-[#4DACF0]">
                      <Sprout size={24} />
                    </div>
                    <div className="text-left">
                      <h4 className="text-[17px] font-bold text-gray-900 mb-0.5">补充养料</h4>
                      <p className="text-[13px] text-gray-500">记录小确幸，化作大树的养分</p>
                    </div>
                  </div>
                  <ChevronRight className="text-gray-300" size={20} />
                </button>
                
                <button 
                  onClick={() => setSearchParams(prev => { const p = new URLSearchParams(prev); p.set('sheet', 'water_list'); return p; })}
                  className="w-full bg-white rounded-2xl p-5 flex items-center justify-between shadow-sm active:scale-95 transition-transform border border-white"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-[#F5F7F6] rounded-full flex items-center justify-center text-gray-600">
                      <ListTree size={24} />
                    </div>
                    <div className="text-left">
                      <h4 className="text-[17px] font-bold text-gray-900 mb-0.5">养料记录</h4>
                      <p className="text-[13px] text-gray-500">回顾那些滋养生命的瞬间</p>
                    </div>
                  </div>
                  <ChevronRight className="text-gray-300" size={20} />
                </button>
              </div>
              <div className="mt-6">
                <HomeIndicator floating={false} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Water Input Bottom Sheet */}
      <AnimatePresence>
        {showWaterSheet && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeSheet}
              className="fixed inset-0 bg-black/40 z-[90] backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-[100] bg-white rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] flex flex-col"
            >
              <div className="flex justify-center pt-3 pb-2" onClick={closeSheet}>
                <div className="w-12 h-1.5 bg-gray-200 rounded-full"></div>
              </div>
              <div className="px-6 py-4">
                <h3 className="text-[20px] font-bold text-gray-900 mb-6 flex items-center">
                  <Droplet className="text-[#4DACF0] mr-2.5" size={24} />
                  给成长树补充点养分吧
                </h3>
                
                <textarea 
                  value={waterText}
                  onChange={(e) => setWaterText(e.target.value)}
                  placeholder="记录今天的开心瞬间..."
                  className="w-full h-24 bg-[#F5F7F6] rounded-2xl p-4 text-[16px] text-gray-900 placeholder:text-gray-400 outline-none resize-none mb-4"
                  autoFocus
                />

                <div className="flex flex-wrap gap-2.5 mb-8">
                  {WATER_TAGS.map(tag => (
                    <button
                      key={tag}
                      onClick={() => setWaterText(prev => prev ? prev + '，' + tag : tag)}
                      className="px-4 py-2 bg-gray-50 border border-gray-100 rounded-full text-[13px] text-gray-600 font-medium active:scale-95 transition-transform"
                    >
                      {tag}
                    </button>
                  ))}
                </div>

                <button 
                  onClick={() => saveWater(waterText)}
                  disabled={!waterText.trim()}
                  className="w-full bg-gray-900 disabled:bg-gray-300 text-white font-bold py-4 rounded-[20px] text-[17px] active:scale-[0.98] transition-transform shadow-xl shadow-gray-900/10"
                >
                  化作养分
                </button>
              </div>
              <div className="pb-6">
                <HomeIndicator floating={false} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Water Review List Bottom Sheet */}
      <AnimatePresence>
        {showWaterList && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeSheet}
              className="fixed inset-0 bg-black/40 z-[90] backdrop-blur-[2px]"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-x-0 bottom-0 z-[100] bg-[#F7F9F8] rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.1)] flex flex-col h-[75vh]"
            >
              <div className="flex justify-center pt-3 pb-2 shrink-0" onClick={closeSheet}>
                <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
              </div>
              <div className="px-6 py-4 flex items-center justify-between shrink-0">
                <h3 className="text-[22px] font-bold text-gray-900 flex items-center">
                  <Droplet className="text-[#4DACF0] mr-2" size={24} />
                  养料记录
                </h3>
                <span className="text-[13px] font-bold text-gray-500 bg-white shadow-sm border border-gray-100 px-3 py-1 rounded-full">{waterRecords.length} 滴</span>
              </div>
              
              <div className="flex-1 overflow-y-auto px-6 py-2 space-y-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                {waterRecords.map(record => (
                  <div key={record.id} className="bg-white rounded-[24px] p-5 shadow-[0_4px_16px_rgb(0,0,0,0.03)] border border-white">
                    <div className="flex items-start space-x-4">
                      <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center text-xl shrink-0">
                        {record.icon}
                      </div>
                      <div className="flex-1 pt-0.5">
                        <p className="text-[16px] text-gray-900 font-medium leading-relaxed mb-4">
                          {record.text}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-[12px] font-bold text-[#4DACF0] bg-blue-50 px-2.5 py-1 rounded-lg">
                            #{record.tag}
                          </span>
                          <span className="text-[12px] text-gray-400 font-medium">
                            {record.date}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="pb-6 pt-2 bg-[#F7F9F8]">
                <HomeIndicator floating={false} />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Share Card Overlay */}
      <AnimatePresence>
        {showCard && (
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.5 }}
            onDragEnd={(e, info) => {
              if (info.offset.y > 100) closeCard();
            }}
            className="fixed inset-0 z-[100] bg-[#111111] flex flex-col text-white font-sans"
          >
            <StatusBar color="white" floating={false} />
            <div className="h-14 flex items-center justify-between px-4 relative">
              <div className="w-16"></div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-12 h-1.5 bg-white/20 rounded-full"></div>
              </div>
              <button 
                onClick={closeCard} 
                className="px-4 py-1.5 bg-white/10 rounded-full text-[14px] font-bold active:bg-white/20 transition-colors"
              >
                完成
              </button>
            </div>
            
            <main className="flex-1 flex flex-col items-center justify-center px-8 pb-10">
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.15 }}
                className="w-full bg-[#F5F7F6] rounded-[32px] overflow-hidden shadow-2xl shadow-white/5"
              >
                <div className="p-8 pb-10 text-center relative text-gray-900">
                  <div className="w-16 h-16 mx-auto bg-white rounded-full flex items-center justify-center text-3xl shadow-sm mb-6 z-10 relative">
                    {displayEmoji}
                  </div>
                  
                  <p className="text-[11px] text-gray-400 font-medium tracking-[0.2em] uppercase mb-2">Milestone</p>
                  <h2 className="text-2xl font-bold mb-4">{displayTitle}</h2>
                  
                  <p className="text-[15px] text-gray-600 leading-relaxed mb-10 text-left px-2">
                    "{displayDesc}"
                  </p>

                  <div className="flex justify-between items-end border-t border-gray-200/60 pt-6">
                    <div className="text-left">
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">{profile.name}来到世界</p>
                      <p className="text-2xl font-bold font-serif text-[#34C759]">{days} <span className="text-sm font-sans font-medium text-gray-400">天</span></p>
                    </div>
                    <div className="text-right pb-1">
                      <p className="text-[10px] text-gray-400 font-medium">来自「小芽成长」</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </main>
            
            <div className="bg-[#1C1C1E] rounded-t-[32px] px-6 pt-6 pb-4">
              <div className="flex justify-center space-x-6 mb-6">
                <button className="flex flex-col items-center space-y-2 group">
                  <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center group-active:bg-white/20 transition-colors">
                    <Download size={24} />
                  </div>
                  <span className="text-xs text-gray-400">保存相册</span>
                </button>
                <button className="flex flex-col items-center space-y-2 group">
                  <div className="w-14 h-14 bg-[#07C160]/20 rounded-full flex items-center justify-center text-[#07C160] group-active:bg-[#07C160]/30 transition-colors">
                    <ShareIcon size={24} />
                  </div>
                  <span className="text-xs text-gray-400">微信分享</span>
                </button>
              </div>
              <HomeIndicator floating={false} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}