import { useNavigate } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { ChevronLeft, Info } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Measurements() {
  const navigate = useNavigate();

  return (
    <div className="w-full h-screen bg-[#F5F7F6] flex flex-col font-sans">
      <div className="bg-[#F5F7F6] z-10">
        <StatusBar color="black" floating={false} />
        <div className="h-14 flex items-center px-4">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-gray-900">
            <ChevronLeft size={28} strokeWidth={2} />
          </button>
          <h1 className="flex-1 text-center text-lg font-bold mr-8">趣味体重记录</h1>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto px-6 pt-6 pb-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[32px] p-8 shadow-[0_8px_30px_rgb(0,0,0,0.04)] text-center relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#A2C0D9]/10 rounded-bl-full z-0 pointer-events-none"></div>
          
          <h2 className="text-[56px] font-bold text-gray-900 mb-1 relative z-10 tracking-tight">7.0<span className="text-xl text-gray-400 ml-1 font-normal tracking-normal">kg</span></h2>
          <p className="text-sm text-gray-500 mb-8 relative z-10 font-medium">今天录入的体重</p>

          <div className="py-8 border-y border-dashed border-gray-100 mb-8 relative z-10">
            <div className="flex justify-center flex-wrap gap-2.5 mb-8 px-2">
              {Array.from({ length: 14 }).map((_, i) => (
                <div key={i} className="text-2xl filter drop-shadow-sm" title="500ml水">💧</div>
              ))}
            </div>
            <div className="flex items-start justify-center space-x-2.5 text-gray-700 bg-[#F7F9F8] p-5 rounded-[20px]">
              <Info size={18} className="text-[#A2C0D9] flex-shrink-0 mt-0.5" />
              <p className="text-[13px] leading-relaxed text-left font-medium">
                约等于 <strong className="text-gray-900 font-bold">14 瓶</strong> 500ml 的矿泉水。<br/>
                <span className="text-gray-500 mt-1.5 inline-block font-normal">抱起来，是沉甸甸的爱。</span>
              </p>
            </div>
          </div>
          
          <button className="w-full bg-gray-900 text-white font-semibold py-4 rounded-2xl active:scale-[0.98] transition-transform relative z-10 shadow-xl shadow-gray-900/10">
            生成分享卡片
          </button>
        </motion.div>
      </main>

      <div className="bg-[#F5F7F6]">
        <HomeIndicator floating={false} />
      </div>
    </div>
  );
}