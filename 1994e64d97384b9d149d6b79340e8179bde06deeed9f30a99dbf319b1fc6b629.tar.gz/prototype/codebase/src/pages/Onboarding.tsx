import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import StatusBar from '../components/mobile-shell/status-bar';
import HomeIndicator from '../components/mobile-shell/home-indicator';
import { RefreshCw, ChevronRight } from 'lucide-react';

export default function Onboarding() {
  const navigate = useNavigate();
  const defaultDate = new Date();
  defaultDate.setDate(defaultDate.getDate() - 128);

  const [name, setName] = useState('小芽');
  const [date, setDate] = useState(defaultDate.toISOString().split('T')[0]);
  const [avatar, setAvatar] = useState('https://picsum.photos/seed/baby1/200/200');

  const isValid = name && date;

  const handleStart = () => {
    localStorage.setItem('baby_profile', JSON.stringify({ name, date, avatar }));
    navigate('/home');
  };

  const cycleAvatar = () => {
    const seeds = ['baby1', 'baby2', 'cute', 'smile', 'joy', 'sun', 'star'];
    const nextSeed = seeds[Math.floor(Math.random() * seeds.length)] + Math.floor(Math.random() * 100);
    setAvatar(`https://picsum.photos/seed/${nextSeed}/200/200`);
  };

  return (
    <div className="w-full h-screen bg-[#F5F7F6] flex flex-col font-sans">
      <div className="bg-[#F5F7F6]">
        <StatusBar color="black" floating={false} />
      </div>
      
      <main className="flex-1 overflow-y-auto px-6 pt-8 pb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">先认识一下宝宝</h1>
        <p className="text-gray-500 mb-10 text-[15px] leading-relaxed">
          填写宝宝信息，开启你们的专属成长树培育之旅。<br/>
          记录越多，小树越茂盛哦。
        </p>

        <div className="bg-white rounded-[24px] p-6 shadow-[0_8px_30px_rgb(0,0,0,0.04)] mb-8">
          <div className="flex justify-center mb-8 relative">
            <div className="relative group">
              <img 
                src={avatar} 
                alt="Avatar" 
                className="w-24 h-24 bg-gray-50 border-4 border-white shadow-md rounded-full object-cover transition-transform"
              />
              <button 
                onClick={cycleAvatar}
                className="absolute bottom-0 right-0 bg-gray-900 text-white w-8 h-8 rounded-full flex items-center justify-center border-2 border-white shadow-sm active:scale-90 transition-transform"
              >
                <RefreshCw size={14} strokeWidth={2.5} />
              </button>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">宝宝昵称</label>
              <input 
                type="text" 
                placeholder="例如：小芽"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-[#34C759]/50 transition-all text-gray-900 placeholder:text-gray-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">出生日期</label>
              <input 
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-[#34C759]/50 transition-all text-gray-900"
              />
            </div>
          </div>
        </div>
      </main>

      <div className="bg-[#F5F7F6] px-6 pb-4 pt-2">
        <button 
          onClick={handleStart}
          disabled={!isValid}
          className="w-full bg-[#34C759] disabled:bg-gray-200 disabled:text-gray-400 text-white font-semibold py-4 rounded-2xl flex items-center justify-center space-x-2 transition-all active:scale-[0.98] shadow-[0_8px_20px_rgba(52,199,89,0.25)] disabled:shadow-none"
        >
          <span>开始记录成长</span>
          <ChevronRight size={20} />
        </button>
        <HomeIndicator floating={false} />
      </div>
    </div>
  );
}