import { motion, AnimatePresence } from 'framer-motion';
import { useMemo, useEffect, useState } from 'react';

export default function GrowthTree({ recordCount, waterCount = 0 }: { recordCount: number, waterCount?: number }) {
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    if (waterCount > 0) {
      setPulse(true);
      const timer = setTimeout(() => setPulse(false), 2500);
      return () => clearTimeout(timer);
    }
  }, [waterCount]);

  const buds = useMemo(() => {
    return Array.from({ length: 50 }).map((_, i) => {
      const angle = (i * 137.5) * (Math.PI / 180);
      const radius = 35 + Math.sqrt(i) * 12; 
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius - 30; 
      return { id: i, x, y };
    });
  }, []);

  return (
    <motion.div 
      className="relative flex flex-col items-center justify-end w-[320px] h-[380px]"
      animate={pulse ? { scale: [1, 1.04, 1], filter: ['brightness(1)', 'brightness(1.15)', 'brightness(1)'] } : { scale: 1 }}
      transition={{ duration: 2.5, ease: "easeInOut" }}
    >
      {/* Background glowing blob */}
      <motion.div 
        animate={{ 
          borderRadius: ["40% 60% 70% 30%", "50% 50% 50% 50%", "60% 40% 30% 70%", "40% 60% 70% 30%"],
          rotate: [0, 90, 180, 360],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute w-[260px] h-[260px] top-[10px] bg-gradient-to-tr from-[#34C759]/25 to-[#A2C0D9]/25 blur-2xl pointer-events-none"
      />

      {/* Tree SVG */}
      <div className="relative w-[260px] h-[320px] z-10 flex flex-col items-center">
        <svg viewBox="0 0 260 320" className="w-full h-full drop-shadow-[0_15px_25px_rgba(52,199,89,0.15)] overflow-visible">
          <defs>
            <linearGradient id="trunk" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9"/>
              <stop offset="100%" stopColor="#E5E7EB" stopOpacity="0.95"/>
            </linearGradient>
            <linearGradient id="canopy" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#34C759" stopOpacity="0.85"/>
              <stop offset="100%" stopColor="#22C55E" stopOpacity="0.6"/>
            </linearGradient>
            <filter id="glass">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7" result="glow" />
              <feBlend in="SourceGraphic" in2="glow" />
            </filter>
          </defs>
          
          {/* Trunk & Branches */}
          <path d="M120,300 C120,230 100,180 130,150 C160,180 140,230 140,300 Z" fill="url(#trunk)" filter="url(#glass)" />
          <path d="M130,170 Q100,135 60,120" stroke="url(#trunk)" strokeWidth="14" strokeLinecap="round" fill="none" filter="url(#glass)" />
          <path d="M130,160 Q165,125 195,115" stroke="url(#trunk)" strokeWidth="12" strokeLinecap="round" fill="none" filter="url(#glass)" />
          <path d="M130,200 Q160,160 185,170" stroke="url(#trunk)" strokeWidth="9" strokeLinecap="round" fill="none" filter="url(#glass)" />
          <path d="M130,210 Q95,170 70,180" stroke="url(#trunk)" strokeWidth="8" strokeLinecap="round" fill="none" filter="url(#glass)" />

          {/* Canopy Shapes (Fluid overlapping circles) */}
          <g filter="url(#glass)">
            <circle cx="130" cy="120" r="95" fill="url(#canopy)" />
            <circle cx="75" cy="145" r="60" fill="url(#canopy)" />
            <circle cx="185" cy="140" r="65" fill="url(#canopy)" />
            <circle cx="130" cy="55" r="55" fill="url(#canopy)" />
            <circle cx="175" cy="85" r="50" fill="url(#canopy)" />
            <circle cx="85" cy="85" r="50" fill="url(#canopy)" />
          </g>
        </svg>

        {/* Buds */}
        <div className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none" style={{ top: '-40px' }}>
          {buds.map((bud, i) => {
            const isActive = i < recordCount;
            const isJustAdded = i === recordCount - 1;
            return (
              <motion.div
                key={bud.id}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ 
                  opacity: isActive ? 1 : 0, 
                  scale: isActive ? 1 : 0 
                }}
                transition={{ 
                  duration: 0.6, 
                  delay: isJustAdded && !pulse ? 0.3 : 0,
                  type: "spring"
                }}
                className="absolute"
                style={{ x: bud.x, y: bud.y }}
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-[#FDE047] blur-[4px] rounded-full opacity-80 animate-pulse" />
                  <div className="w-2.5 h-2.5 bg-white rounded-full shadow-[0_0_10px_2px_rgba(253,224,71,0.6)] relative z-10" />
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </motion.div>
  );
}