import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Check } from 'lucide-react';

export const GROWTH_NODES = [
  { id: 'smile', title: '第一次微笑', icon: '😊' },
  { id: 'lift_head', title: '第一次抬头', icon: '👶' },
  { id: 'turn_over', title: '第一次翻身', icon: '🔄' },
  { id: 'laugh', title: '第一次笑出声', icon: '😆' },
  { id: 'recognize', title: '第一次认人', icon: '👀' },
  { id: 'sit', title: '第一次独坐', icon: '🪑' },
  { id: 'tooth', title: '第一次长牙', icon: '🦷' },
  { id: 'solid_food', title: '第一次吃辅食', icon: '🥣' },
  { id: 'crawl', title: '第一次爬行', icon: '🐛' },
  { id: 'clap', title: '第一次拍手', icon: '👏' },
  { id: 'wave', title: '第一次挥手', icon: '👋' },
  { id: 'call_mama', title: '第一次叫妈妈', icon: '👩' },
  { id: 'call_papa', title: '第一次叫爸爸', icon: '👨' },
  { id: 'stand', title: '第一次站立', icon: '🧍' },
  { id: 'walk', title: '第一次走路', icon: '👣' },
  { id: 'point', title: '用手指物', icon: '👉' },
  { id: 'eat_alone', title: '自己吃饭', icon: '🥄' },
  { id: 'run', title: '第一次跑', icon: '🏃' },
  { id: 'jump', title: '双脚跳', icon: '🦘' },
  { id: 'sentence', title: '说句子', icon: '💬' },
  { id: 'friend', title: '交朋友', icon: '🤝' },
  { id: 'share', title: '分享', icon: '🎁' },
  { id: 'sing', title: '唱歌', icon: '🎵' },
  { id: 'draw', title: '画画', icon: '🎨' },
  { id: 'potty', title: '自己如厕', icon: '🚽' },
  { id: 'dress', title: '自己穿衣', icon: '👕' },
  { id: 'tricycle', title: '骑三轮车', icon: '🚲' },
  { id: 'count', title: '数数', icon: '1️⃣' },
  { id: 'story', title: '讲故事', icon: '📖' },
  { id: 'swim', title: '游泳', icon: '🏊' },
  { id: 'school', title: '上幼儿园', icon: '🎒' },
];

export default function GrowthMap() {
  const navigate = useNavigate();

  const ITEM_HEIGHT = 130;
  const START_OFFSET = 80;
  const mapHeight = (GROWTH_NODES.length + 1) * ITEM_HEIGHT + 200;
  
  const getPath = (nodes: any[], startIndex = 0, endIndex = nodes.length + 1) => {
    let d = '';
    for (let i = startIndex; i < endIndex; i++) {
      const x = 195 + Math.sin(i * 0.7) * 110;
      const y = i * ITEM_HEIGHT + START_OFFSET;
      if (i === startIndex) {
        d += `M ${x} ${y}`;
      } else {
        d += ` L ${x} ${y}`;
      }
    }
    return d;
  };

  const recordedCount = 2; // Fixed state for prototype demonstration

  return (
    <div className="relative w-full overflow-hidden bg-gradient-to-b from-[#EAF4EF] to-[#F5F9F7]" style={{ height: mapHeight }}>
      <svg className="absolute top-0 left-0 w-full pointer-events-none" style={{ height: mapHeight }} viewBox={`0 0 390 ${mapHeight}`}>
        <path 
          d={getPath(GROWTH_NODES, recordedCount - 1)} 
          fill="none" 
          stroke="#C2E2D1" 
          strokeWidth="12" 
          strokeDasharray="16 16"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path 
          d={getPath(GROWTH_NODES, 0, recordedCount)} 
          fill="none" 
          stroke="#34C759" 
          strokeWidth="12"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      {[...GROWTH_NODES, { id: 'tbc', title: '未完待续...', icon: '✨', isTbc: true }].map((node, i) => {
        const x = 195 + Math.sin(i * 0.7) * 110;
        const y = i * ITEM_HEIGHT + START_OFFSET;
        const isRecorded = i < recordedCount;
        const isNext = i === recordedCount;
        const isTbc = (node as any).isTbc;

        return (
          <motion.div
            key={node.id}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: Math.min(i * 0.05, 1) }}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
            style={{ left: `${(x / 390) * 100}%`, top: y }}
          >
            <button
              onClick={() => {
                if (!isTbc) {
                  if (isRecorded) {
                    navigate(`/home?show_card=true&template=${node.id}&emoji=${encodeURIComponent(node.icon)}&custom_title=${encodeURIComponent(node.title)}`);
                  } else {
                    navigate(`/record?template=${node.id}`);
                  }
                }
              }}
              className={`relative flex items-center justify-center rounded-full transition-all ${!isTbc && !isRecorded ? 'active:scale-95' : ''} ${
                isRecorded 
                  ? 'w-[72px] h-[72px] bg-white shadow-[0_12px_30px_rgba(52,199,89,0.3)] border-4 border-[#34C759] z-20' 
                  : isNext 
                    ? 'w-16 h-16 bg-white shadow-xl border-4 border-[#34C759] animate-pulse z-20'
                    : isTbc
                      ? 'w-14 h-14 bg-white/50 border-4 border-dashed border-[#C2E2D1] shadow-sm z-10'
                      : 'w-14 h-14 bg-[#F2F6F4] border-4 border-white shadow-sm grayscale opacity-70 z-10'
              }`}
            >
              <span className={isRecorded ? 'text-[32px]' : 'text-2xl'}>{node.icon}</span>
              {isRecorded && (
                <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-[#34C759] rounded-full border-[3px] border-white flex items-center justify-center text-white shadow-sm">
                  <Check size={14} strokeWidth={4} />
                </div>
              )}
            </button>
            
            <div className={`mt-2.5 px-3.5 py-1.5 rounded-full text-[13px] font-bold whitespace-nowrap shadow-sm transition-all ${
              isRecorded 
                ? 'bg-[#34C759] text-white shadow-[0_4px_10px_rgba(52,199,89,0.3)] scale-105' 
                : isNext
                  ? 'bg-white text-gray-800 border border-gray-100 scale-105'
                  : isTbc
                    ? 'bg-transparent text-[#34C759] shadow-none'
                    : 'bg-white/80 text-gray-400'
            }`}>
              {node.title}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}